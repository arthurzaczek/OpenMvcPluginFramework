﻿function alertFail() {
    document.alert("Fail");
}