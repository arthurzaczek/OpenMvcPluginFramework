﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.ComponentModel.Composition;
using OpenMvcPluginFramework;
using OpenMvcPluginFramework.ActionFilters;
using OpenMvcPluginFramework.Interfaces;
using OpenMvcPluginFramework.PluginResources;

namespace $safeprojectname$
{
    [Export(typeof(IPlugin))]
    //Adjust meta data
    [PluginMetaData("Plugin", "Demo Example")]
    public class Plugin: PluginBase
    {
        public Plugin()
        {
            base.AddScriptResource(new EmbeddedPluginResource(GetResourceLocation("Scripts", "script1.js")));
            base.AddCssResource(new EmbeddedPluginResource(GetResourceLocation("Css", "style1.css")));
            base.AddElement(new PluginElement() { Id = "Home", Controller = "PluginHome", Action = "Index", ActionFilter = new NullActionFilter() });
        }
    }
}